
import argparse
import time
import requests
import pandas as pd
from pathlib import Path

API = "https://api.worldbank.org/v2/country/{country}/indicator/{indicator}?date={start}:{end}&format=json&per_page=20000"

def fetch_indicator(country, indicator, start, end):
    url = API.format(country=country, indicator=indicator, start=start, end=end)
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    js = r.json()
    if not isinstance(js, list) or len(js) < 2:
        return pd.DataFrame()
    rows = js[1] or []
    df = pd.DataFrame([
        {"region": row.get("country", {}).get("id"),
         "year": int(row["date"]),
         "value": float(row["value"]) if row["value"] is not None else None}
        for row in rows
    ])
    return df.dropna()

def main(config_path: str, outdir: str = "data/raw"):
    import yaml
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(Path(config_path).read_text())
    wb = cfg.get("worldbank", {})
    start = wb.get("start_year", 2000)
    end = wb.get("end_year", 2024)
    countries = wb.get("countries", ["USA"])
    indicators = wb.get("indicators", [{"code": "GE.EST"}])

    for ind in indicators:
        code = ind["code"]
        for c in countries:
            df = fetch_indicator(c, code, start, end)
            if df.empty:
                continue
            df["id"] = f"worldbank_{code}"
            fp = out / f"worldbank_{code}_{c}.csv"
            df.to_csv(fp, index=False)
            time.sleep(0.5)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--outdir", default="data/raw")
    args = ap.parse_args()
    main(args.config, args.outdir)
