# simulation/plot_csv.py
import argparse, os, csv
import numpy as np
import matplotlib.pyplot as plt

def load_csv(path):
    with open(path, 'r', newline='') as f:
        r = csv.DictReader(f)
        rows = [row for row in r]
    return rows

def plot_1d(rows, out_png):
    param = rows[0]['param']
    values = np.array([float(r['value']) for r in rows])
    aucs   = np.array([float(r['auc'])   for r in rows])
    fig, ax = plt.subplots(figsize=(7,4))
    ax.plot(values, aucs, marker='o')
    ax.set_xlabel(param)
    ax.set_ylabel('AUC of M(t) (stability proxy)')
    ax.set_title(f"Sweep: {param}")
    fig.tight_layout()
    fig.savefig(out_png, dpi=180)
    print(f"Wrote plot: {out_png}")

def plot_2d(rows, out_png):
    p1 = rows[0]['p1']; p2 = rows[0]['p2']
    v1s = sorted(set(float(r['v1']) for r in rows))
    v2s = sorted(set(float(r['v2']) for r in rows))
    X = { (float(r['v2']), float(r['v1'])): float(r['auc']) for r in rows }

    Z = np.zeros((len(v2s), len(v1s)))
    for i, v2 in enumerate(v2s):
        for j, v1 in enumerate(v1s):
            Z[i, j] = X[(v2, v1)]

    fig, ax = plt.subplots(figsize=(7,5))
    im = ax.imshow(Z, origin='lower', aspect='auto',
                   extent=[min(v1s), max(v1s), min(v2s), max(v2s)])
    ax.set_xlabel(p1); ax.set_ylabel(p2)
    ax.set_title(f"AUC of M(t) across {p1} × {p2}")
    fig.colorbar(im, ax=ax, label="AUC(M)")
    fig.tight_layout()
    fig.savefig(out_png, dpi=180)
    print(f"Wrote plot: {out_png}")

def main():
    import sys
    if '--csv' not in sys.argv:
        print('Usage: python -m simulation.plot_csv --csv path/to/sweep.csv')
        return
    idx = sys.argv.index('--csv') + 1
    csv_path = sys.argv[idx]
    rows = load_csv(csv_path)
    out_png = os.path.splitext(csv_path)[0] + '_replot.png'
    cols = set(rows[0].keys())
    if {'param','value','auc'}.issubset(cols):
        plot_1d(rows, out_png)
    elif {'p1','v1','p2','v2','auc'}.issubset(cols):
        plot_2d(rows, out_png)
    else:
        raise ValueError('Unrecognized CSV schema.')

if __name__ == '__main__':
    main()
